<?php
require_once 'koneksi_db.php';
require_once 'models/Anak.php';
//1. tangkap request dari form
$nama = $_POST['nama'];
$nik = $_POST['nik'];
$tgl_lahir = $_POST['tgl_lahir'];
$tmpt = $_POST['tempat_lahir'];
$usia = $_POST['usia'];
$jk = $_POST['jenis_kelamin'];
$id_ibu = $_POST['ibu_id'];
$tombol = $_POST['proses'];
//2. masukkan ke data array
$data = [
  $nama,
  $nik,
  $tgl_lahir,
  $tmpt,
  $usia,
  $jk,
  $id_ibu
];
$obj = new Anak();
//logik untuk tombol
switch ($tombol) {
    case 'simpan': $obj->simpan($data); break;
    case 'ubah':
        $data[]=$_POST['idx']; // ? ke 4 where id = ? yg didapat dari hidden field form edit
        $obj->ubah($data);
        break;
        case 'hapus':
          unset($data); //hapus 7 ? di array $data
          $data[]=$_POST['idx']; // ? ke 1 where id = ? yg didapat dari hidden field        
          $obj->hapus($data);
          break;         
      default:
      header('location:index.php?hal=anak');
  }
  header('location:index.php?hal=anak');