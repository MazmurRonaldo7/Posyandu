<?php
require_once 'koneksi_db.php';
require_once 'models/Imunisasi.php';
//1. tangkap request dari form
$tgl = $_POST['tgl_imunisasi'];
$usia = $_POST['usia_imunisasi'];
$tinggi_badan = $_POST['tinggi_badan'];
$berat_badan = $_POST['berat_badan'];
$per= $_POST['periode'];
$anak= $_POST['anak_id'];
$id_ibu = $_POST['ibu_id'];
$vak = $_POST['vaksin_id'];
$pet = $_POST['petugas_id'];

$tombol = $_POST['proses'];
//2. masukkan ke data array
$data = [
  $tgl,
  $usia,
  $tinggi_badan,
  $berat_badan,
  $per,
  $anak,
  $id_ibu,
  $vak,
  $pet
];
$obj = new Imunisasi();
//logik untuk tombol
switch ($tombol) {
    case 'simpan': $obj->simpan($data); break;
    case 'ubah':
        $data[]=$_POST['idx']; // ? ke 4 where id = ? yg didapat dari hidden field form edit
        $obj->ubah($data);
        break;
        case 'hapus':
          unset($data); //hapus 7 ? di array $data
          $data[]=$_POST['idx']; // ? ke 1 where id = ? yg didapat dari hidden field        
          $obj->hapus($data);
          break;         
      default:
      header('location:index.php?hal=imunisasi');
  }
  header('location:index.php?hal=imunisasi');