<div class="row">
                <div class="col-md-12 mb-4 stretch-card transparent">
                  <div class="card card-light-danger">
                    <div class="card-body">
                      <h1 class="mb-4">Sorry...</h1>
                      <p class="fs-30 mb-2">Anda Gagal</p>
                      <p>Login</p>
                    </div>
                    
                  </div>
                </div>
                    <a  href="index.php?hal=login" class="nav-link" type="submit">Back to login...</a>
              </div>