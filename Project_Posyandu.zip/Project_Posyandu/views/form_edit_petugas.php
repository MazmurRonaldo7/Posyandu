<?php
    //tangkap request url: index.php?hal=gedung_form_edit&id=3
    $id = $_REQUEST['id'];
    //buat object Gedung
    $obj = new Petugas();
    //panggil fungsi untuk mendapatkan data sebuah gedung di modelnya
    $data = $obj->getPetugas($id);
    ?>
<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Tambah Edit</h4>
                  <p class="card-description">
                    Petugas
                  </p>
                  <form class="forms-sample" action="petugasController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Petugas</label>
                      <input name="nama" type="text" class="form-control" id="Inputvaksin" placeholder="Nama Anak" value="<?= $data['nama'] ?>">
                        </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Jenis Kelamin</label>
                      <input name="jenis_kelamin" type="text" class="form-control" id="Inputvaksin" placeholder="Jenis Kelamin" value="<?= $data['jenis_kelamin'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Alamat</label>
                      <textarea name="alamat" class="form-control" id="Inputketerangan" placeholder="Alamat"><?= $data['alamat'] ?></textarea>
                        </div>
                        <div class="form-group">
                      <label for="exampleInputUsername1">NO HP</label>
                      <input name="no_hp" type="text" class="form-control" id="Inputvaksin" placeholder="No HP" value="<?= $data['no_hp'] ?>">
                    </div> 
                    <div class="form-group">
                      <label for="exampleInputUsername1">Jabatan</label>
                      <input name="jabatan" type="text" class="form-control" id="Inputvaksin" placeholder="Jabatan" value="<?= $data['jabatan'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Foto</label>
                      <input name="foto" type="text" class="form-control" id="Inputvaksin" placeholder="Foto" value="<?= $data['foto'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Ibu</label>
                      <input name="data_posyandu_id" type="text" class="form-control" id="Inputvaksin" placeholder="Posyandu" value="<?= $data['data_posyandu_id'] ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="ubah">Simpan</button>
                    <input type="hidden" name="idx" value="<?= $id ?>"> 
                  </form>
                </div>
              </div>
            </div>