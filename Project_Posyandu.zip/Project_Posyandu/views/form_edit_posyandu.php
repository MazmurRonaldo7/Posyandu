<?php
    //tangkap request url: index.php?hal=gedung_form_edit&id=3
    $id = $_REQUEST['id'];
    //buat object Gedung
    $obj = new Posyandu();
    //panggil fungsi untuk mendapatkan data sebuah gedung di modelnya
    $data = $obj->getPosyandu($id);
    ?>
<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Edit Data</h4>
                  <p class="card-description">
                  <?= $data['nama'] ?>
                  </p>
                  <form class="forms-sample" action="posyanduController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Posyandu</label>
                      <input name="nama" type="text" class="form-control" id="Inputvaksin" placeholder="Nama Posyandu"  value="<?= $data['nama'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Alamat</label>
                      <textarea name="alamat" class="form-control" id="Inputketerangan" placeholder="Alamat"><?= $data['alamat'] ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="ubah">Simpan</button>
                    <input type="hidden" name="idx" value="<?= $id ?>"> 
                </form>
                </div>
              </div>
            </div>