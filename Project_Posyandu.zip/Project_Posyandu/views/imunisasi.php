<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data Imunisasi</h4>
                  <p class="card-description">
                  <a  href="index.php?hal=form_imun" class="btn btn-primary py-2 px-4" type="submit">Tambah + </a>
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Tanggal Imunisasi</th>
                          <th>Usia Imunisasi</th>
                          <th>Tinggi Badan</th>
                          <th>Berat Badan</th>
                          <th>Periode</th>
                          <th>Anak</th>
                          <th>Ibu</th>
                          <th>Vaksin</th>
                          <th>Petugas</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <?php
                     $obj = new Imunisasi();
                     $rs = $obj->getAll();
                     foreach($rs as $a){
                        ?>
                      <tbody>
                        <tr>
                          <td><?= $a['tgl_imunisasi'] ?></td>
                          <td> <?= $a['usia_imunisasi'] ?></td>
                          <td> <?= $a['tinggi_badan'] ?></td>
                          <td> <?= $a['berat_badan'] ?></td>
                          <td> <?= $a['periode'] ?></td>
                          <td> <?= $a['anak_id'] ?></td>
                          <td> <?= $a['ibu_id'] ?></td>
                          <td> <?= $a['vaksin_id'] ?></td>
                          <td> <?= $a['petugas_id'] ?></td>
                          <form method="POST" action="imunController.php">
                          <td> <a  href="index.php?hal=imun_detail&id=<?= $a['id'] ?>" class="btn btn-info py-2 px-4" type="submit"> <i class="icon-paper menu-icon"></i></a>
                          <a  href="index.php?hal=form_edit_imun&id=<?= $a['id'] ?>" class="btn btn-primary py-2 px-4" type="submit">  <i class="fas fa-edit"></i></a>
                          <button class="btn btn-danger py-2 px-4 icon-trash menu-icon" type="submit" name="proses" value="hapus"
                        onclick="return confirm('Anda Yakin Data dihapus?')"></button>
                        <input type="hidden" name="idx" value="<?= $a['id'] ?>" />
                        </form>
                        </td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>