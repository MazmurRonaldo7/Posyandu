<?php
    
    $id = $_REQUEST['id'];
    //ciptakan object
    $obj = new User();
    $data = $obj->getUser($id); 
    ?>
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <a href="index.php?hal=user" class="btn btn-primary py-2 px-6"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    <br/>
                  <br/>
                  <h4 class="card-title"><?= $data['username'] ?></h4>
                  <p class="card-description">
                    Detail data <code>User</code>
                  </p>
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                     
                      <tbody>
                        <tr class="table-info">
                          <td>
                          <?= $data['username'] ?>
                          </td>
                          <td>
                          <?= $data['password'] ?>
                          </td>
                          <td>
                          <?= $data['role'] ?>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>