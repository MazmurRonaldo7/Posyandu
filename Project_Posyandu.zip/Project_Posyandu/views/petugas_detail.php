<?php
    
    $id = $_REQUEST['id'];
    //ciptakan object
    $obj = new Petugas();
    $data = $obj->getPetugas($id); 
    ?>
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <a href="index.php?hal=petugas" class="btn btn-primary py-2 px-6"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    <br/>
                  <br/>
                <p class="card-description">
                    Detail data <code>Petugas</code>
                  </p>
                  <h4 class="card-title"><?= $data['nama'] ?></h4>
                  
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                     
                      <tbody>
                        <tr class="table-danger">
                          <td>
                          <?= $data['nama'] ?>
                          </td>
                          <td>
                          <?= $data['jenis_kelamin'] ?>
                          </td>
                          <td>
                          <?= $data['alamat'] ?>
                          </td>
                          <td>
                          <?= $data['no_hp'] ?>
                          </td>
                          <td>
                          <?= $data['jabatan'] ?>
                          </td>
                          <td>
                          <?= $data['foto'] ?>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>