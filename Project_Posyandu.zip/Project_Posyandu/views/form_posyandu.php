<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Tambah Data</h4>
                  <p class="card-description">
                    Posyandu
                  </p>
                  <form class="forms-sample" action="posyanduController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Posyandu</label>
                      <input name="nama" type="text" class="form-control" id="Inputvaksin" placeholder="Nama Posyandu">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Alamat</label>
                      <textarea name="alamat" class="form-control" id="Inputketerangan" placeholder="Alamat"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="simpan">Simpan</button>
                  </form>
                </div>
              </div>
            </div>