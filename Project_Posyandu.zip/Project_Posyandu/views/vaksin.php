<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data Vaksin</h4>
                  <p class="card-description">
                  <a  href="index.php?hal=form_vaksin" class="btn btn-primary py-2 px-4" type="submit">Tambah + </a>
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Nama vaksin</th>
                          <th>Keterangan</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <?php
                     $obj = new Vaksin();
                     $rs = $obj->getAll();
                     foreach($rs as $v){
                        ?>
                      <tbody>
                        <tr>
                          <td><?= $v['nama'] ?></td>
                          <td> <?= $v['keterangan'] ?></td>
                          <form method="POST" action="vaksinController.php">
                          <td> <a  href="index.php?hal=vaksin_detail&id=<?= $v['id'] ?>" class="btn btn-info py-2 px-4" type="submit"> <i class="icon-paper menu-icon"></i></a>
                          <a  href="index.php?hal=form_edit_vaksin&id=<?= $v['id'] ?>" class="btn btn-primary py-2 px-4" type="submit">  <i class="fas fa-edit"></i></a>
                          <button class="btn btn-danger py-2 px-4 icon-trash menu-icon" type="submit" name="proses" value="hapus"
                        onclick="return confirm('Anda Yakin Data dihapus?')"></button>
                        <input type="hidden" name="idx" value="<?= $v['id'] ?>" />
                        </form>
                        </td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>