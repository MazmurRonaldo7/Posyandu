<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data Petugas</h4>
                  <p class="card-description">
                  <a  href="index.php?hal=form_petugas" class="btn btn-primary py-2 px-4" type="submit">Tambah + </a>
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Nama Petugas</th>
                          <th>Jenis Kelamin</th>
                          <th>Alamat</th>
                          <th>No HP</th>
                          <th>Jabatan</th>
                          <th>Foto</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <?php
                     $obj = new Petugas();
                     $rs = $obj->getAll();
                     foreach($rs as $t){
                        ?>
                      <tbody>
                        <tr>
                          <td><?= $t['nama'] ?></td>
                          <td> <?= $t['jenis_kelamin'] ?></td>
                          <td> <?= $t['alamat'] ?></td>
                          <td> <?= $t['no_hp'] ?></td>
                          <td> <?= $t['jabatan'] ?></td>
                          <td> <?= $t['foto'] ?></td>
                         
                          <form method="POST" action="petugasController.php">
                          <td> <a  href="index.php?hal=petugas_detail&id=<?= $t['id'] ?>" class="btn btn-info py-2 px-4" type="submit"> <i class="icon-paper menu-icon"></i></a>
                          <?php
            if($role=='admin'){
            ?> <a  href="index.php?hal=form_edit_petugas&id=<?= $t['id'] ?>" class="btn btn-primary py-2 px-4" type="submit">  <i class="fas fa-edit"></i></a>
                          <button class="btn btn-danger py-2 px-4 icon-trash menu-icon" type="submit" name="proses" value="hapus"
                        onclick="return confirm('Anda Yakin Data dihapus?')"></button>
                        <input type="hidden" name="idx" value="<?= $t['id'] ?>" />
                        <?php } ?>
                        </form>
                        </td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>