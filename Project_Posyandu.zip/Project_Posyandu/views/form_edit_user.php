<?php
    //tangkap request url: index.php?hal=gedung_form_edit&id=3
    $id = $_REQUEST['id'];
    //buat object Gedung
    $obj = new User();
    //panggil fungsi untuk mendapatkan data sebuah gedung di modelnya
    $data = $obj->getUser($id);
    ?>
<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Edit Data</h4>
                  <p class="card-description">
                    User
                  </p>
                  <form class="forms-sample" action="userController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Username</label>
                      <input name="username" type="text" class="form-control" id="Inputvaksin" placeholder="Nama User" value="<?= $data['username'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Password</label>
                      <input name="password" type="text" class="form-control" id="Inputvaksin" placeholder="Password" value="<?= $data['password'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Role</label>
                      <input name="role" type="text" class="form-control" id="Inputvaksin" placeholder="Role User" value="<?= $data['role'] ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="ubah">Simpan</button>
                    <input type="hidden" name="idx" value="<?= $id ?>"> 
                  </form>
                </div>
              </div>
            </div>