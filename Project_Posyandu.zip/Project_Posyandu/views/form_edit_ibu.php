<?php
    //tangkap request url: index.php?hal=gedung_form_edit&id=3
    $id = $_REQUEST['id'];
    //buat object Gedung
    $obj = new Ibu();
    //panggil fungsi untuk mendapatkan data sebuah gedung di modelnya
    $data = $obj->getIbu($id);
    ?>
<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Edit Data</h4>
                  <p class="card-description">
                    Ibu
                  </p>
                  <form class="forms-sample" action="ibuController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Ibu</label>
                      <input name="nama" type="text" class="form-control" id="Inputvaksin" placeholder="Nama Ibu"  value="<?= $data['nama'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">NIK Ibu</label>
                      <input name="nik" type="text" class="form-control" id="Inputvaksin" placeholder="NIK Ibu"  value="<?= $data['nik'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Alamat</label>
                      <textarea name="alamat" class="form-control" id="Inputketerangan" placeholder="Alamat"><?= $data['alamat'] ?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">No HP</label>
                      <input name="no_hp" type="text" class="form-control" id="Inputvaksin" placeholder="No HP"  value="<?= $data['no_hp'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Foto</label>
                      <input name="foto" type="text" class="form-control" id="Inputvaksin" placeholder="Foto"  value="<?= $data['foto'] ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="ubah">Simpan</button>
                    <input type="hidden" name="idx" value="<?= $id ?>"> 
                  </form>
                </div>
              </div>
            </div>