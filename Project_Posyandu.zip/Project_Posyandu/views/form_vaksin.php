<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Tambah Data</h4>
                  <p class="card-description">
                    Vaksin
                  </p>
                  <form class="forms-sample" action="vaksinController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Vaksin</label>
                      <input name="nama" type="text" class="form-control" id="Inputvaksin" placeholder="Nama Vaksin">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Keterangan</label>
                      <textarea name="keterangan" class="form-control" id="Inputketerangan" placeholder="Keterangan Vaksin"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="simpan">Simpan</button>
                  </form>
                </div>
              </div>
            </div>