<?php
    //tangkap request url: index.php?hal=gedung_form_edit&id=3
    $id = $_REQUEST['id'];
    //buat object Gedung
    $obj = new Anak();
    //panggil fungsi untuk mendapatkan data sebuah gedung di modelnya
    $data = $obj->getAnak($id);
    ?>

<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Edit Data</h4>
                  <p class="card-description">
                    Anak
                  </p>
                  <form class="forms-sample" action="anakController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Anak</label>
                      <input name="nama" type="text" class="form-control" id="Inputvaksin" placeholder="Nama Anak"  value="<?= $data['nama'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">NIK Anak</label>
                      <input name="nik" type="text" class="form-control" id="Inputvaksin" placeholder="NIK Anak"  value="<?= $data['nik'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Tanggal Lahir</label>
                      <input name="tgl_lahir" type="date" class="form-control" id="Inputvaksin" placeholder="Tanggal Lahir"  value="<?= $data['tgl_lahir'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Tempat Lahir</label>
                      <input name="tempat_lahir" type="text" class="form-control" id="Inputvaksin" placeholder="Tempat Lahir"  value="<?= $data['tempat_lahir'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Usia</label>
                      <input name="usia" type="text" class="form-control" id="Inputvaksin" placeholder="Usia"  value="<?= $data['usia'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Jenis Kelamin</label>
                      <input name="jenis_kelamin" type="text" class="form-control" id="Inputvaksin" placeholder="Jenis Kelamin" value="<?= $data['jenis_kelamin'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Ibu</label>
                      <input name="ibu_id" type="text" class="form-control" id="Inputvaksin" placeholder="Ibu" value="<?= $data['ibu_id'] ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="ubah">Simpan</button>
                    <input type="hidden" name="idx" value="<?= $id ?>"> 
                  </form>
                </div>
              </div>
            </div>