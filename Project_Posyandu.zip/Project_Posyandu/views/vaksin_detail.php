<?php
    
    $id = $_REQUEST['id'];
    //ciptakan object
    $obj = new Vaksin();
    $data = $obj->getVaksin($id); 
    ?>
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <a href="index.php?hal=vaksin" class="btn btn-primary py-2 px-6"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    <br/>
                  <br/>
                  <h4 class="card-title"><?= $data['nama'] ?></h4>
                  <p class="card-description">
                    Detail data <code>Nama vaksin dan keterangannya</code>
                  </p>
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                     
                      <tbody>
                        <tr class="table-info">
                          <td>
                          <?= $data['nama'] ?>
                          </td>
                          <td>
                          <?= $data['keterangan'] ?>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>