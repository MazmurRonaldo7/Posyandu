<?php
    
    $id = $_REQUEST['id'];
    //ciptakan object
    $obj = new Imunisasi();
    $data = $obj->getImunisasi($id); 
    ?>
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <a href="index.php?hal=imunisasi" class="btn btn-primary py-2 px-6"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    <br/>
                  <br/>
                <p class="card-description">
                    Detail data <code>Imunisasi</code>
                  </p>
                  
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                     
                      <tbody>
                        <tr class="table-danger">
                          <td>
                          <?= $data['tgl_imunisasi'] ?>
                          </td>
                          <td>
                          <?= $data['usia_imunisasi'] ?>
                          </td>
                          <td>
                          <?= $data['tinggi_badan'] ?>
                          </td>
                          <td>
                          <?= $data['berat_badan'] ?>
                          </td>
                          <td>
                          <?= $data['periode'] ?>
                          </td>
                          <td>
                          <?= $data['anak_id'] ?>
                          </td>
                          <td>
                          <?= $data['ibu_id'] ?>
                          </td>
                          <td>
                          <?= $data['vaksin_id'] ?>
                          </td>
                          <td>
                          <?= $data['petugas_id'] ?>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>