<?php
   
    $id = $_REQUEST['id'];
    $obj = new Imunisasi();
    $data = $obj->getImunisasi($id);
    ?>

<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Edit Data</h4>
                  <p class="card-description">
                    Imunisasi
                  </p>
                  <form class="forms-sample" action="imunController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Tanggal Imunisasi</label>
                      <input name="tgl_imunisasi" type="date" class="form-control" id="Inputvaksin" placeholder="Tanggal Imunisasi" value="<?= $data['tgl_imunisasi'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Usia Imunisasi</label>
                      <input name="usia_imunisasi" type="text" class="form-control" id="Inputvaksin" placeholder="Usia Imunisasi" value="<?= $data['usia_imunisasi'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Tinggi Badan</label>
                      <input name="tinggi_badan" type="text" class="form-control" id="Inputvaksin" placeholder="Tinggi Badan" value="<?= $data['tinggi_badan'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Berat Badan</label>
                      <input name="berat_badan" type="text" class="form-control" id="Inputvaksin" placeholder="Berat Badan" value="<?= $data['berat_badan'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Periode</label>
                      <input name="periode" type="text" class="form-control" id="Inputvaksin" placeholder="Periode" value="<?= $data['periode'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Anak</label>
                      <input name="anak_id" type="text" class="form-control" id="Inputvaksin" placeholder="Anak" value="<?= $data['anak_id'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Ibu</label>
                      <input name="ibu_id" type="text" class="form-control" id="Inputvaksin" placeholder="Ibu" value="<?= $data['ibu_id'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Vaksin</label>
                      <input name="vaksin_id" type="text" class="form-control" id="Inputvaksin" placeholder="Vaksin" value="<?= $data['vaksin_id'] ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Petugas</label>
                      <input name="petugas_id" type="text" class="form-control" id="Inputvaksin" placeholder="Petugas" value="<?= $data['petugas_id'] ?>">
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="ubah">Simpan</button>
                    <input type="hidden" name="idx" value="<?= $id ?>"> 
                  </form>
                </div>
              </div>
            </div>