<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Tambah Data</h4>
                  <p class="card-description">
                    User
                  </p>
                  <form class="forms-sample" action="userController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Username</label>
                      <input name="username" type="text" class="form-control" id="Inputvaksin" placeholder="Nama User">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Password</label>
                      <input name="password" type="text" class="form-control" id="Inputvaksin" placeholder="Password">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Role</label>
                      <input name="role" type="text" class="form-control" id="Inputvaksin" placeholder="Role User">
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="simpan">Simpan</button>
                  </form>
                </div>
              </div>
            </div>