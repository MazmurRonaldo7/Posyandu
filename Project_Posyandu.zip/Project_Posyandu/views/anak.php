<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data Anak</h4>
                  <p class="card-description">
                  <a  href="index.php?hal=form_anak" class="btn btn-primary py-2 px-4" type="submit">Tambah + </a>
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Nama Anak</th>
                          <th>Nik</th>
                          <th>Tanggal Lahir</th>
                          <th>Tempat Lahir</th>
                          <th>Usia</th>
                          <th>Jenis Kelamin</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <?php
                     $obj = new Anak();
                     $rs = $obj->getAll();
                     foreach($rs as $a){
                        ?>
                      <tbody>
                        <tr>
                          <td><?= $a['nama'] ?></td>
                          <td> <?= $a['nik'] ?></td>
                          <td> <?= $a['tgl_lahir'] ?></td>
                          <td> <?= $a['tempat_lahir'] ?></td>
                          <td> <?= $a['usia'] ?></td>
                          <td> <?= $a['jenis_kelamin'] ?></td>
                          
                          <form method="POST" action="anakController.php">
                          <td> <a  href="index.php?hal=anak_detail&id=<?= $a['id'] ?>" class="btn btn-info py-2 px-4" type="submit"> <i class="icon-paper menu-icon"></i></a>
                          <a  href="index.php?hal=form_edit_anak&id=<?= $a['id'] ?>" class="btn btn-primary py-2 px-4" type="submit">  <i class="fas fa-edit"></i></a>
                          <button class="btn btn-danger py-2 px-4 icon-trash menu-icon" type="submit" name="proses" value="hapus"
                        onclick="return confirm('Anda Yakin Data dihapus?')"></button>
                        <input type="hidden" name="idx" value="<?= $a['id'] ?>" />
                        </form>
                      
                        </td>
                      
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>