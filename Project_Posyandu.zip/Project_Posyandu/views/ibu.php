<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data Ibu</h4>
                  <p class="card-description">
                  <a  href="index.php?hal=form_ibu" class="btn btn-primary py-2 px-4" type="submit">Tambah + </a>
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Nama Ibu</th>
                          <th>Nik</th>
                          <th>Alamat</th>
                          <th>Nomor Handphone</th>
                          <th>Foto</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <?php
                     $obj = new Ibu();
                     $rs = $obj->getAll();
                     foreach($rs as $i){
                        ?>
                      <tbody>
                        <tr>
                          <td><?= $i['nama'] ?></td>
                          <td> <?= $i['nik'] ?></td>
                          <td> <?= $i['alamat'] ?></td>
                          <td> <?= $i['no_hp'] ?></td>
                          <td> <?= $i['foto'] ?></td>
                          <form method="POST" action="ibuController.php">
                          <td> <a  href="index.php?hal=ibu_detail&id=<?= $i['id'] ?>" class="btn btn-info py-2 px-4" type="submit"> <i class="icon-paper menu-icon"></i></a>
                          <a  href="index.php?hal=form_edit_ibu&id=<?= $i['id'] ?>" class="btn btn-primary py-2 px-4" type="submit">  <i class="fas fa-edit"></i></a>
                          <button class="btn btn-danger py-2 px-4 icon-trash menu-icon" type="submit" name="proses" value="hapus"
                        onclick="return confirm('Anda Yakin Data dihapus?')"></button>
                        <input type="hidden" name="idx" value="<?= $i['id'] ?>" />
                        </form>
                        </td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>