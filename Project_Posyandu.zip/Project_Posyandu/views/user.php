<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data User</h4>
                  <p class="card-description">
                  <a  href="index.php?hal=form_user" class="btn btn-primary py-2 px-4" type="submit">Tambah + </a>
                  </p>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Nama User</th>
                          <th>Password</th>
                          <th>Role</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <?php
                     $obj = new User();
                     $rs = $obj->getAll();
                     foreach($rs as $u){
                        ?>
                      <tbody>
                        <tr>
                          <td><?= $u['username'] ?></td>
                          <td> <?= $u['password'] ?></td>
                          <td><?= $u['role'] ?></td>
                          <form method="POST" action="userController.php">
                          <td> <a  href="index.php?hal=user_detail&id=<?= $u['id'] ?>" class="btn btn-info py-2 px-4" type="submit"> <i class="icon-paper menu-icon"></i></a>
                          <a  href="index.php?hal=form_edit_user&id=<?= $u['id'] ?>" class="btn btn-primary py-2 px-4" type="submit">  <i class="fas fa-edit"></i></a>
                          <button class="btn btn-danger py-2 px-4 icon-trash menu-icon" type="submit" name="proses" value="hapus"
                        onclick="return confirm('Anda Yakin Data dihapus?')"></button>
                        <input type="hidden" name="idx" value="<?= $u['id'] ?>" />
                        </form>
                        </td>
                        </tr>
                      </tbody>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>