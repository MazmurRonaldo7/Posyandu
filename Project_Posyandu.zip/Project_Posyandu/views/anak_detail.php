<?php
    
    $id = $_REQUEST['id'];
    //ciptakan object
    $obj = new Anak();
    $data = $obj->getAnak($id); 
    ?>
<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <a href="index.php?hal=anak" class="btn btn-primary py-2 px-6"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
                    <br/>
                  <br/>
                <p class="card-description">
                    Detail data <code>Anak</code>
                  </p>
                  <h4 class="card-title"><?= $data['nama'] ?></h4>
                  
                  <div class="table-responsive pt-3">
                    <table class="table table-bordered">
                     
                      <tbody>
                        <tr class="table-danger">
                          <td>
                          <?= $data['nama'] ?>
                          </td>
                          <td>
                          <?= $data['nik'] ?>
                          </td>
                          <td>
                          <?= $data['tgl_lahir'] ?>
                          </td>
                          <td>
                          <?= $data['tempat_lahir'] ?>
                          </td>
                          <td>
                          <?= $data['usia'] ?>
                          </td>
                          <td>
                          <?= $data['jenis_kelamin'] ?>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>