
     </div> <div class="col-md-12 grid-margin transparent">
              <div class="row">
                <div class="col-md-12 mb-4 stretch-card transparent">
                  <div class="card card-tale">
                    <div class="card-body">
                    <div class="tab-pane" id="timeline">
                    <!-- The timeline -->
                    <span class="subheading">Aplikasi</span>
                      <h2 class="mb-4">Pendataan posyandu</h2>
                      <p>Aplikasi ini merupakan sebuah aplikasi website khusus pendataan posyandu di suatu daerah.</p>
                      <p>Tujuan dari pembuatan website ini adalah untuk mempermudah para kader atau petugas posyandu dalam proses pendataan.</p>
                      <p> <a href="index.php?hal=home" class="btn btn-white py-3 px-4">Back to home...</a></p>
                    </div>
                  </div>
                </div>