<div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Form Tambah Data</h4>
                  <p class="card-description">
                    Ibu
                  </p>
                  <form class="forms-sample" action="ibuController.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Nama Ibu</label>
                      <input name="nama" type="text" class="form-control" id="Inputvaksin" placeholder="Nama Ibu">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">NIK Ibu</label>
                      <input name="nik" type="text" class="form-control" id="Inputvaksin" placeholder="NIK Ibu">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Alamat</label>
                      <textarea name="alamat" class="form-control" id="Inputketerangan" placeholder="Alamat"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">No HP</label>
                      <input name="no_hp" type="text" class="form-control" id="Inputvaksin" placeholder="No HP">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Foto</label>
                      <input name="foto" type="text" class="form-control" id="Inputvaksin" placeholder="Foto">
                    </div>
                    <button type="submit" class="btn btn-primary mr-3" name="proses" value="simpan">Simpan</button>
                  </form>
                </div>
              </div>
            </div>