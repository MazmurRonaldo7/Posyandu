<?php
require_once 'koneksi_db.php';
require_once 'models/Petugas.php';
//1. tangkap request dari form
$nama = $_POST['nama'];
$jk = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];
$noHP = $_POST['no_hp'];
$jab = $_POST['jabatan'];
$foto = $_POST['foto'];
$id_pos = $_POST['data_posyandu_id'];
$tombol = $_POST['proses'];
//2. masukkan ke data array
$data = [
  $nama,
  $jk,
  $alamat,
  $noHP,
  $jab,
  $foto,
  $id_pos
];
$obj = new Petugas();
//logik untuk tombol
switch ($tombol) {
    case 'simpan': $obj->simpan($data); break;
    case 'ubah':
        $data[]=$_POST['idx']; // ? ke 4 where id = ? yg didapat dari hidden field form edit
        $obj->ubah($data);
        break;
        case 'hapus':
          unset($data); //hapus 7 ? di array $data
          $data[]=$_POST['idx']; // ? ke 1 where id = ? yg didapat dari hidden field        
          $obj->hapus($data);
          break;         
      default:
      header('location:index.php?hal=petugas');
  }
  header('location:index.php?hal=petugas');