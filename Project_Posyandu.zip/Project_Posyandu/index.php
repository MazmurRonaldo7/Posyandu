<?php
session_start(); //memulai session
$member = $_SESSION['MEMBER'];
$role = $member['role'];

require_once 'koneksi_db.php';
require_once 'models/Vaksin.php';
require_once 'models/Anak.php';
require_once 'models/Imunisasi.php';
require_once 'models/Ibu.php';
require_once 'models/Posyandu.php';
require_once 'models/Petugas.php';
require_once 'models/Member.php';
require_once 'models/User.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>App Pendataan Posyandu</title>
  <!-- plugins:css -->
  <?php include_once 'file_css.php';?>
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php include_once 'frontend/navbar.php';?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
      <?php include_once 'frontend/setting.php';?>
     
      <!-- partial:partials/_sidebar.html -->
      <?php include_once 'frontend/sidebar.php';?>
      
      <div class="main-panel">
      <?php include_once 'frontend/content-wrapper.php';?>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php include_once 'frontend/footer.php';?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>   
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <?php include_once 'file_js.php';?>
  <!-- End custom js for this page-->
</body>
</html>

