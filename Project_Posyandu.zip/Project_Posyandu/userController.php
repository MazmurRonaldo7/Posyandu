<?php
require_once 'koneksi_db.php';
require_once 'models/User.php';
//1. tangkap request dari form
$nama = $_POST['username'];
$ket = $_POST['password'];
$role = $_POST['role'];
$tombol = $_POST['proses'];
//2. masukkan ke data array
$data = [
  $nama, 
  $ket,
  $role 
];
$obj = new User();
//logik untuk tombol
switch ($tombol) {
    case 'simpan': $obj->simpan($data); break;
    case 'ubah':
        $data[]=$_POST['idx']; // ? ke 4 where id = ? yg didapat dari hidden field form edit
        $obj->ubah($data);
        break;
        case 'hapus':
          unset($data); //hapus 7 ? di array $data
          $data[]=$_POST['idx']; // ? ke 1 where id = ? yg didapat dari hidden field        
          $obj->hapus($data);
          break;         
      default:
      header('location:index.php?hal=user');
  }
  header('location:index.php?hal=user');