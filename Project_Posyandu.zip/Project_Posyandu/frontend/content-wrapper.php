<div class="content-wrapper">

    <?php include_once 'header.php'?>
    <?php
        $hal = $_GET['hal'];
        if($hal == 'home'){
            include_once 'frontend/home.php';
        }
        else if(!empty($hal)){
            include_once 'views/'.$hal.'.php';
        }
        else{
            include_once 'frontend/home.php';
        }
        ?>

         