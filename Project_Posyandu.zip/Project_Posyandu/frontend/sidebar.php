<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=home">
              <i class="icon-grid menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <?php
            if(isset($member)){
            ?>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="icon-layout menu-icon"></i>
              <span class="menu-title">Data Pages</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
              <li class="nav-item">
            <a class="nav-link" href="index.php?hal=vaksin">
            <i class="icon-paper menu-icon"></i>
              <span class="menu-title">Data Vaksin</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=imunisasi">
              <i class="fas fa-book menu-icon"></i>
              <span class="menu-title">Data imunisasi</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=posyandu">
            <i class="icon-paper menu-icon"></i>
              <span class="menu-title">Data Posyandu</span>
            </a>
          </li>
          <li class="nav-item">
            
            <a class="nav-link" href="index.php?hal=anak">
           <i class="icon-head menu-icon"></i>
              <span class="menu-title">Data Anak</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=ibu">
            <i class="icon-head menu-icon"></i>
              <span class="menu-title">Data Ibu</span>
            </a>
          </li>
         
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=petugas">
            <i class="icon-head menu-icon"></i>
              <span class="menu-title">Data Petugas</span>
            </a>
          </li>
          <?php
            if($role=='admin'){
            ?>
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=user">
            <i class="icon-paper menu-icon"></i>
              <span class="menu-title">Data User</span>
            </a>
          </li>
          <?php } ?>
              </ul>
            </div>
          </li>
          <?php
            }
            ?>
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=login">
            <i class="icon-head menu-icon"></i>
              <span class="menu-title">Login</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.php?hal=about">
            <i class="fas fa-info menu-icon"></i>
              <span class="menu-title"> About us</span>
            </a>
</li>
<li class="nav-item">
            <a class="nav-link" href="index.php?hal=contact">
            <i class="fa fa-address-book menu-icon" aria-hidden="true"></i>
              <span class="menu-title"> Contact us</span>
            </a>
</li>
        </ul>
      </nav>