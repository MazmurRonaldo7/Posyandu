<?php
class Imunisasi{
    //member1 var
    public $koneksi;
    //member2 konstruktor
    public function __construct(){
        global $dbh; //panggil instance obj PDO di koneksi_db.php
        $this->koneksi = $dbh; // instance obj PDO di assign ke var koneksi   
    }
    //member3 method2 terkait CRUD
    public function getAll(){
        $sql = "SELECT * FROM data_imunisasi";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll();
        return $rs;
    }
    public function simpan($data){
        $sql = "INSERT INTO data_imunisasi (tgl_imunisasi,usia_imunisasi,tinggi_badan,berat_badan,periode,anak_id,ibu_id,vaksin_id,petugas_id) VALUES (?,?,?,?,?,?,?,?,?)";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }        
    public function getImunisasi($id){
        $sql = "SELECT * FROM data_imunisasi WHERE id = ?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch();
        return $rs;
    }
    public function ubah($data){
        $sql = "UPDATE data_imunisasi SET  tgl_imunisasi=?, usia_imunisasi=?, tinggi_badan=?, berat_badan=?, periode=?, anak_id=?, ibu_id=?, vaksin_id=?, petugas_id=? WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }    
    public function hapus($data){
        $sql = "DELETE FROM data_imunisasi WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }   
}