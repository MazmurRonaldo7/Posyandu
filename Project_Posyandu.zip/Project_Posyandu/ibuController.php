<?php
require_once 'koneksi_db.php';
require_once 'models/Ibu.php';
//1. tangkap request dari form
$nama = $_POST['nama'];
$nik = $_POST['nik'];
$alamat = $_POST['alamat'];
$noHP = $_POST['no_hp'];
$foto = $_POST['foto'];
$tombol = $_POST['proses'];
//2. masukkan ke data array
$data = [
  $nama,
  $nik,
  $alamat,
  $noHP,
  $foto
];
$obj = new Ibu();
//logik untuk tombol
switch ($tombol) {
    case 'simpan': $obj->simpan($data); break;
    case 'ubah':
        $data[]=$_POST['idx']; // ? ke 4 where id = ? yg didapat dari hidden field form edit
        $obj->ubah($data);
        break;
        case 'hapus':
          unset($data); //hapus 7 ? di array $data
          $data[]=$_POST['idx']; // ? ke 1 where id = ? yg didapat dari hidden field        
          $obj->hapus($data);
          break;         
      default:
      header('location:index.php?hal=ibu');
  }
  header('location:index.php?hal=ibu');